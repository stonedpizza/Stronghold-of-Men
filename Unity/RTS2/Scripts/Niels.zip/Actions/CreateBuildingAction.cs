﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;



public class CreateBuildingAction : ActionBehavior
{
    public GameObject GhostBuilding;
        private GameObject active = null;
    public override Action GetClickAction()
    {
        return delegate () {

            var go = GameObject.Instantiate(GhostBuilding);
            go.AddComponent<BuildingSite>();
            active = go;
            };
    }
    private void Update()
    {
        if (active == null)
            return;
        if (Input.GetKeyDown(KeyCode.Escape))
            GameObject.Destroy(active);
    }
    private void OnDestroy()
    {
        if (active == null)
            return;
        Destroy(active);
    }

}





